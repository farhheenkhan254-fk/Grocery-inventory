import pytest
from database.connection import init_db
from database.repository import repo
from tools.inventory_tools import check_stock_status, scan_all_inventory
from tools.purchase_tools import calculate_reorder_plan

@pytest.fixture(autouse=True)
def setup_db():
    init_db()

def test_sufficient_stock_detection():
    # Basmati Rice min is 10.0; set to 20.0
    repo.set_stock("Basmati Rice", 20.0)
    status = check_stock_status("Basmati Rice")
    assert status["status"] == "SUFFICIENT"
    assert status["needs_reorder"] is False
    assert status["current_stock"] == 20.0

def test_low_stock_detection():
    # Set to 5.0 kg (below min of 10.0 kg)
    repo.set_stock("Basmati Rice", 5.0)
    status = check_stock_status("Basmati Rice")
    assert status["status"] == "LOW_STOCK"
    assert status["needs_reorder"] is True
    assert status["current_stock"] == 5.0
    assert status["minimum_stock"] == 10.0

def test_out_of_stock_detection():
    # Set to 0.0 kg
    repo.set_stock("Basmati Rice", 0.0)
    status = check_stock_status("Basmati Rice")
    assert status["status"] == "OUT_OF_STOCK"
    assert status["needs_reorder"] is True

def test_reorder_plan_calculation():
    # Product with 5kg current, 10kg min, 50kg base reorder
    plan = calculate_reorder_plan(current_stock=5.0, minimum_stock=10.0, base_reorder=50.0)
    assert plan["suggested_quantity"] == 50.0
    assert plan["deficit"] == 5.0
    assert plan["urgency"] in ["HIGH", "CRITICAL", "MEDIUM"]

def test_scan_all_inventory_finds_low_items():
    repo.set_stock("Basmati Rice", 5.0)
    low_items = scan_all_inventory()
    names = [item["product_name"] for item in low_items]
    assert "Basmati Rice" in names
